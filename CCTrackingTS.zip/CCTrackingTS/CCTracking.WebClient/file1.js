﻿define(["require", "exports"], function(require, exports) {
    var temp = (function () {
        function temp() {
        }
        return temp;
    })();
    exports.temp = temp;
});
//# sourceMappingURL=file1.js.map
