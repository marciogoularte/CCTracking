﻿/// <reference path="../../Scripts/typings/require/require.d.ts" />
/// <reference path="../../Scripts/typings/marionette/marionette.d.ts" />
/// <amd-dependency path="jquery"/>
//export class BaseDto extends Backbone.Model {
//    private ajaxRequest: IBaseDto;
//}
//aaa
//# sourceMappingURL=BaseDto.js.map
